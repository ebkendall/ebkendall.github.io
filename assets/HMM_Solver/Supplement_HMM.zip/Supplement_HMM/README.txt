This directory contains additional figures for the paper, Beyond
time-homogeneity for continuous-time multistate Markov models.  

Supplement_A.pdf provides a Table of Contents for the other .pdf files
in this directory.
