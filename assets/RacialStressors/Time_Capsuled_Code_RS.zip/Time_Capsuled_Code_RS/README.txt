This directory contains the code to reproduce the results in the paper, Prior exposure to racial discrimination and patterns of acute parasympathetic nervous system responses among Black adults.  
Please contact Dr. Vanessa V. Volpe at vvvolpe@ncus.edu for questions regarding data availability.
Please contact Emmett B. Kendall at ebkendal@ncsu.edu for any help or questions with the code.

See workflow.sh for line-by-line Unix command line code for reproducing the results.