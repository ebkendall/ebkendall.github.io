This directory contains the code to reproduce the results in the paper, The EAS
approach for graphical selection consistency in vector autoregression models.

See workflow.sh for line-by-line Unix command line code for reproducing the 
results.  Running the command,

bash workflow.sh 

will reproduce all numerical results presented in the manuscript, but will take
many days.  If it is desired to reproduce the results, it is best to follow the
instructions in workflow.sh and parallelize accordingly on a computing cluster.
Setting fewer MCMC steps will also speed up computations, but will yield 
differing results.

The directory Tables/ contains .csv files of the data to produce Tables 2-7 in
the Simulation results section of the manuscript.

The directory Real_Data/ contains the .pdf files of Figures 2 and 3 in the 
Real data application section of the manuscript, as well as time-series plots 
of the first-differenced data.

The directory Simple_example/ contains the code for creating Figure 1 an Table 1.