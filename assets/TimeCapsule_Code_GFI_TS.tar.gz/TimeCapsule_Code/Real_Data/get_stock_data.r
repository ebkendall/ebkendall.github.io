library(BatchGetSymbols)

Dir_out = '../Plots/'

tickers = c('WMT','XOM','CVX','F','PFE','AAPL','MSFT','INTC')
names=c('Walmart','Exxon','Chevron','Ford','Pfizer','Apple','Microsoft','Intel')

# WMT : Walmart
# XOM : Exxon Mobil
# CVX : Chevron
# F : Ford Motor
# PFE : Pfizer
# AAPL : Apple
# MSFT : Microsoft
# INTC : Intel

temp = BatchGetSymbols( tickers=tickers, first.date="1994-12-1", 
                              last.date="2018-12-31", freq.data='monthly')
cat('\n')
															
stock_dates = as.data.frame(reshape.wide(temp$df.tickers)$price.close[,1])
stocks = diff( as.matrix(reshape.wide(temp$df.tickers)$price.close[,-1]) )
colnames(stocks) = names


stocks_list = list( stocks[1:144,], stocks[181:288,])


periods = c( '1995-2006', '2010-2018')
pdf(paste0(Dir_out,'time-series_plots.pdf'))
par(mfrow=c(3, 2))
for(t in 1:length(periods)){
	for(j in 1:length(names)){
		plot(stocks_list[[t]][,j], xlab='month', ylab=NA, ylim=c(-15,15),
			   main=paste0('1st diff ',names[j],' for ',periods[t]))
	}
}
dev.off()

write.table( x=stock_dates[-1,], file='stock_dates.csv', sep=',', row.names=F)
write.table( x=stocks_list[[1]], file='stocks_1.csv', sep=',', row.names=F)
write.table( x=stocks_list[[2]], file='stocks_2.csv', sep=',', row.names=F)
