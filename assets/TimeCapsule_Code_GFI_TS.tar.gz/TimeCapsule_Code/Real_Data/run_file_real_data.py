# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python run_file_real_data.py time_period steps burnin N

from routine_EAS_VAR1 import *
import sys

seed = 1
np.random.seed(int(seed))
time_period = sys.argv[1]  # time_period options: 1, 2
steps = int(sys.argv[2])
burnin = int(sys.argv[3])
N = int(sys.argv[4])

data = np.loadtxt( 'stocks_'+time_period+'.csv', delimiter=',', skiprows=1)
data = np.transpose(data)
p, n = data.shape
scrY = data[:,1:n]
scrX = data[:,0:(n-1)]


# -----------------------------------------------------------------------------
# Run the epsilon-admissible subsets (EAS) mcmc algorithm
# -----------------------------------------------------------------------------
Output = EAS_VAR( scrY, scrX, steps, burnin, N=N)

Output.to_pickle( 'EAS_stocks_'+time_period+'.pickle')
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# Implement lasso and elastic net 
# -----------------------------------------------------------------------------
Y = ( scrY[:,].flatten('F') ).reshape(((n-1)*p,1))
scrZ = sparse.csr_matrix(np.kron( np.transpose(scrX), np.eye(p)))

tscv = TimeSeriesSplit(n_splits=2)
lasso = ElasticNetCV( l1_ratio=1, cv=tscv, fit_intercept=False)
lasso.fit( scrZ, Y.flatten())
A_hat_lasso = (lasso.coef_).reshape((p,p), order='F')

np.set_printoptions(precision=4)
print(A_hat_lasso)

enet = ElasticNetCV( l1_ratio=[.1, .5, .7, .9, .95, .99, 1], cv=tscv,                                                             fit_intercept=False)
enet.fit( scrZ, Y.flatten())
A_hat_enet = (enet.coef_).reshape((p,p), order='F') 
print(A_hat_enet)
# -----------------------------------------------------------------------------