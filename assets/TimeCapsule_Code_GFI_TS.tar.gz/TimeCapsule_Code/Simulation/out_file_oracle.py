# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python out_file_oracle.py coef_pattern p n num_data_sets Dir


import numpy as np
import pandas as pd
import scipy.linalg as linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as splinalg
import os
import sys



# -----------------------------------------------------------------------------
# Function to determine whether Condition 2 is satisfied.
# -----------------------------------------------------------------------------
def cond2( G, vecA, scrZ_G, n, p, po=None):
	
	po = ( min( p**2, n) if po is None else po )
	
	maxIter = 500 
	p_G = len(G)
	K = p_G - 1
	
	# g0 = (np.transpose(scrZ_G) @ sampled_invW @ scrZ_G).toarray()
	# Recall Sigma = I_p for the simulations
	g0 = (np.transpose(scrZ_G) @ scrZ_G).toarray()
	Lambda_G = np.sum(g0.diagonal())
	
	# Initialize: Set the coefficient estimate with smallest 
	# magnitude equal to 0.
	b = np.array(vecA)
	b[ np.where(abs(b) == np.min(abs(b)))[0][0] ] = 0
	# Max eigenvalue, squared.
	L = linalg.eigh(g0)[0][-1]**2
	g1 = g0 @ g0
	objG = np.transpose(vecA - b) @ g1 @(vecA - b)/2
	objGprev = objG + 1

	iterations = 0
	while (objGprev - objG > pow(10,-4) and iterations < maxIter):

		objGprev = objG
		c = b - g1 @ (b - vecA) / L 
		Kth_Largest = np.partition( abs(c), p_G-K)[p_G-K]
		b = np.zeros(p_G)
		b[abs(c) >= Kth_Largest] = c[abs(c) >= Kth_Largest]

		objG = (np.transpose(vecA - b) @ g1 @ (vecA - b) /2)
		iterations = iterations + 1	
	
	if objGprev - objG < 0:
		objG = objGprev
	
	asympt_comp = max( 1, n**.51 *p**2 *(np.log(np.log(n))*len(G)/2 -po))
	epsilon = Lambda_G * asympt_comp
	
	return (objG/2 > epsilon)
# -----------------------------------------------------------------------------



coef_pattern = sys.argv[1]
p = int(sys.argv[2])
n = int(sys.argv[3])
num_data_sets = int(sys.argv[4])
Dir = sys.argv[5]



MAP_model_size = np.zeros(num_data_sets)
l2_error = np.zeros(num_data_sets)
lF_error = np.zeros(num_data_sets)
est_error = np.zeros(num_data_sets)
min_eig_cov = np.zeros(num_data_sets)
cond2_satisfied = np.zeros(num_data_sets)

count = 0
for seed in range(num_data_sets):
	if (os.path.isfile( Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+
	                                               str(seed+1)+'.csv' ) == True ):
		data = np.loadtxt(Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+
		                                          str(seed+1)+'.csv', delimiter=',')
	
		# True data generating model information ----------------------------------
		true_par = pd.read_pickle(Dir+'true_par_'+coef_pattern+'_'+str(p)+'p_'+
		                                                  str(seed+1)+'.pickle')
		A = true_par['A'].toarray()
		Sigma = true_par['Sigma']
	
		G_true = np.zeros(p**2,dtype=bool)
		G_true[abs(A).flatten('F') > 0] = True
		MAP_model_size[seed] = sum(G_true)
	
		G_true_index = np.where(abs(A).flatten('F') > 0)[0]
		# -------------------------------------------------------------------------

		# Compute the prediction error and estimation error statistics, using 
		# the MAP model 
		# Testing data
		scrY_test = data[:,n:(2*n)]
		scrX_test = data[:,(n-1):(2*n-1)]
	
		# Comute l2_error, lF_error, and est_error for Oracle model ---------------
		# Training data
		scrY = data[:,0:n]
		scrX = np.concatenate( (np.zeros((p,1)), data[:,0:(n-1)]), axis=1)
		Y = ( scrY[:,].flatten('F') ).reshape((n*p,1))
		scrZ = sparse.csr_matrix(np.kron( np.transpose(scrX), np.eye(p)))
	
		# Use the training data to compute A_hat via least squares
		scrZ_true = scrZ[:,G_true]
		vecA_hat_true = (splinalg.inv( np.transpose(scrZ_true) @ scrZ_true ) @
						                              np.transpose(scrZ_true) @ Y).flatten()
		temp = np.zeros(p**2)
		temp[G_true] = vecA_hat_true
		A_hat_true = temp.reshape((p,p), order='F')
	
		# Calculate the out-of-sample prediction error and the white noise 
		# covariance estimator
		pred_error_true = scrY_test - A_hat_true @ scrX_test
		Sigma_hat_true = pred_error_true @ np.transpose(pred_error_true) /n
	
		# Compute/record the spectral and Frobenius norms of the white noise 
		# covariance estimator, and the Frobenius norm of the estimation error 
		# as a ratio of the Frobenius norm of the true coefficient matrix
		l2_error[seed] = max(abs(linalg.svd(Sigma_hat_true, compute_uv=False)))
		lF_error[seed] = np.sum(np.diag( Sigma_hat_true ))**.5
		est_error[seed] = ( np.trace( (A_hat_true - A) @ 
		    np.transpose(A_hat_true - A) )**.5 / np.trace( A @ np.transpose(A))**.5)
		# = ||A_hat - A||_F / ||A||_F
		# -------------------------------------------------------------------------
		
		# Compute components for Conditions 1 and 2 -------------------------------
		E_Omega = linalg.block_diag( scrY @ np.transpose(scrY) /n, np.eye(p))
		min_eig_cov[seed] = np.sqrt(n) * min(linalg.eigvalsh(E_Omega))
		
		vecA = (A.flatten('F'))[G_true]
		cond2_satisfied[seed] = cond2(G_true_index, vecA, scrZ_true, n, p)
				
		count = count +1


print('count = ', count)
if count < 100:
	print('Oracle pattern = '+coef_pattern+' n = '+str(n)+' p = '+str(p))


results = pd.Series( [str(np.round(np.mean(l2_error),2)),
											'('+str(np.round(np.std(l2_error),2))+')',
								      str(np.round(np.mean(lF_error),2)),
											'('+str(np.round(np.std(lF_error),2))+')',
										  str(np.round(np.mean(est_error),2)), 
											'('+str(np.round(np.std(est_error),2))+')',
										  str(np.round(np.mean(MAP_model_size),2)),
											'('+str(np.round(np.std(MAP_model_size),2))+')',
										  None, None,
											None, None,
											None, None,
											None,
											str(np.round(np.mean(min_eig_cov),4)),
										  '('+str(np.round(np.std(min_eig_cov),4))+')',
											str(np.round(np.mean(cond2_satisfied),4))], 
										  index=['L2', '',
														 'LF', '',
														 'est err', '',
														 'active comp', '',
														 'FPR', '',
														 'FNR', '',
														 'prob truth', '',
														 'prop correct',
													   'min_eig_cov', '',
													 	 'cond2_satisfied'])


results.to_pickle(Dir+'results_'+'oracle_'+coef_pattern+'_'+str(p)+'p_'+str(n)+
                                                                  'n'+'.pickle')
				  
				  
				  
				  
				  
				  