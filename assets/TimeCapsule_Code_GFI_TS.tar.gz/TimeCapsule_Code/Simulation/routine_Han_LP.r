# R code provided by Fang Han from Han, Lu, and Liu (2015)
# The cross-validation procedure is as described in the paper, but coded by
# Jonathan Williams for use in Williams, Xie, and Hannig (2019+)
library(lpSolve)


linprogS <- function( Sigma, e, lambda) {
  p <- nrow(Sigma)
  if (p!=ncol(Sigma)) stop("Sigma should be a square matrix!")

  f.obj <- rep(1, 2*p)
  W <- rbind(cbind(-Sigma,Sigma), cbind(Sigma,-Sigma))
  b1 <- - e - lambda
  b2 <- + e - lambda
  f.con <- rbind(diag(2*p), W)
  f.dir <- rep(">=", 4*p)
  f.rhs <- c(rep(0,2*p), b1, b2)
  lp.out <- lp("min", f.obj, f.con, f.dir, f.rhs)
  beta <- lp.out$solution[1:p] - lp.out$solution[(p+1):(2*p)]
  if (lp.out$status == 2){
	  warning("No feasible solution!  Try a larger lambda maybe!")
  }
  return(beta)
}


clime <- function( X, nlambda){
   d=dim(X)[2]
   n=dim(X)[1]
   A=array(0,dim=c(d,d,nlambda))
   SS=cov(X)
   SS1=0
   for(i in 1:(n-1)){
      SS1=SS1+X[i,]%*%t(X[i+1,])
   }
   SS1=SS1/(n-1)
   for(sp in 1:nlambda){
      lambda = seq(1,0.001,length.out=nlambda)[sp]
      for(j in 1:d){
         A[,j,sp]=linprogS(SS, t(SS1)[,j],lambda)
	  }
   }
   return(A)
}


clime_cv <- function( X, nlambda, n1=NULL, n2=NULL){
    d=dim(X)[2]
    n=dim(X)[1]
	if(is.null(n1))  n1 = floor(n/2)
	if(is.null(n2))  n2 = floor(n/2)
	
	t0 = n 
	Err = rep( 0, nlambda)
	for(t in (t0-n2+1):t0){
		A_array = clime( X[ (t-n1):(t-1),], nlambda)
		for(lambda in 1:nlambda){
			pred_err = t(X[t,,drop=F]) - A_array[,,lambda]%*%t(X[t-1,,drop=F])
			Err[lambda] = Err[lambda] + sqrt(sum(pred_err^2))
		}
	}
	avg_Err = Err/n2
	index_lambda_min = min( which(avg_Err == min(avg_Err)) )

	return(index_lambda_min)
}



#x=matrix(rnorm(100),20,5)
#clime(x,10)



