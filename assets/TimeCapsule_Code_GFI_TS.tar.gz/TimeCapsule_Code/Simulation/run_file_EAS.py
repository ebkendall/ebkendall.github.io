# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python run_file_EAS.py seed coef_pattern p n Dir steps burnin N

from routine_EAS_VAR1 import *
import sys
import tempfile

seed = sys.argv[1]
np.random.seed(int(seed))
coef_pattern = sys.argv[2]  
# coef_pattern options: 'band', 'cluster', 'hub', 'random', 'scale-free'
p = int(sys.argv[3])
n = int(sys.argv[4])
Dir = sys.argv[5]
steps = int(sys.argv[6])
burnin = int(sys.argv[7])
N = int(sys.argv[8])

data = np.loadtxt( Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+seed+
                                                          '.csv', delimiter=',')
scrY = data[:,0:n]
scrX = np.concatenate( (np.zeros((p,1)), data[:,0:(n-1)]), axis=1)


# -----------------------------------------------------------------------------
# Run the epsilon-admissible subsets (EAS) mcmc algorithm
# -----------------------------------------------------------------------------
Output = EAS_VAR( scrY, scrX, steps, burnin, N=N)

Output.to_pickle( Dir+'EAS_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+
                                                                 seed+'.pickle')
# -----------------------------------------------------------------------------
