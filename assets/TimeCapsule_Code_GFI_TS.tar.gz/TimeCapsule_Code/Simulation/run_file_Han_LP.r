# To run from command line... 
# $ Rscript run_file_Han.py seed coef_pattern p n Dir
source('routine_Han_LP.r')

args = commandArgs(TRUE)
seed = args[1]
coef_pattern = args[2]
p = args[3]
n = args[4]
Dir = args[5]
set.seed(as.integer(seed))


data = read.table(paste0( Dir,'data_',coef_pattern,'_',p,'p_',n,'n_',seed,
                          '.csv'), header=FALSE, sep=',')
scrY = as.matrix(data[,1:as.integer(n)])
colnames(scrY) = NULL


# -----------------------------------------------------------------------------
# Implement the direct estimation linear program procedure of Han et al (2015) 
# -----------------------------------------------------------------------------
index_lambda_min = suppressWarnings( clime_cv( t(scrY), 10) )
A_hat = clime( t(scrY), 10)[,,index_lambda_min]

write.table( A_hat, col.names=FALSE, row.names=FALSE, sep=',',
	        file=paste0(Dir,'Han_LP_',coef_pattern,'_',p,'p_',n,'n_',seed,'.csv'))
# -----------------------------------------------------------------------------
