# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python run_file_lasso_ridge.py seed coef_pattern p n Dir

from routine_EAS_VAR1 import *
import sys


seed = sys.argv[1]
np.random.seed(int(seed))
coef_pattern = sys.argv[2]  
# coef_pattern options: 'band', 'cluster', 'hub', 'random', 'scale-free'
p = int(sys.argv[3])
n = int(sys.argv[4])
Dir = sys.argv[5]

data = np.loadtxt( Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+seed+
                                                          '.csv', delimiter=',')
scrY = data[:,0:n]
scrX = np.concatenate( (np.zeros((p,1)), data[:,0:(n-1)]), axis=1)
Y = ( scrY[:,].flatten('F') ).reshape((n*p,1))
scrZ = sparse.csr_matrix(np.kron( np.transpose(scrX), np.eye(p)))


# -----------------------------------------------------------------------------
# Implement lasso and elastic net 
# -----------------------------------------------------------------------------
tscv = TimeSeriesSplit(n_splits=3)
lasso = ElasticNetCV( l1_ratio=1, cv=tscv, fit_intercept=False)
lasso.fit( scrZ, Y.flatten())
A_hat_lasso = (lasso.coef_).reshape((p,p), order='F') 

np.savetxt( Dir+'lasso_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+seed+
                               '.csv', A_hat_lasso, delimiter=',', newline='\n')


enet = ElasticNetCV( l1_ratio=[.1, .5, .7, .9, .95, .99, 1], cv=tscv, 
                                                            fit_intercept=False)
enet.fit( scrZ, Y.flatten())
A_hat_enet = (enet.coef_).reshape((p,p), order='F') 

np.savetxt( Dir+'enet_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+seed+
                                '.csv', A_hat_enet, delimiter=',', newline='\n')
# -----------------------------------------------------------------------------
