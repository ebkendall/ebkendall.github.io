#!/bin/bash


# Simple toy example
cp routine_EAS_VAR1.py Simple_example/
cd Simple_example/
python simple_example.py
cd ..


# Simulation results
cp routine_EAS_VAR1.py Simulation/
cd Simulation/
# Generate the synthetic data and implement the estimation procedures
# That this for-loop is most efficiently run in parallelon a computing cluster
# Will take 1-2 days to finish the simulation, in parallel 
for i in {1..100} 
do
# small p large n
python generate_data.py $i random 4 120 ''
Rscript run_file_Han_LP.r $i random 4 120 ''
python run_file_lasso_enet.py $i random 4 120 ''
python run_file_EAS.py $i random 4 120 ''	30000 15000 30
for coef_pattern in band cluster hub random scale-free
do
# Small VAR
python generate_data.py $i $coef_pattern 10 20 ClusterOut/
Rscript run_file_Han_LP.r $i $coef_pattern 10 20 ClusterOut/
python run_file_lasso_enet.py $i $coef_pattern 10 20 ClusterOut/
python run_file_EAS.py $i $coef_pattern 10 20 ClusterOut/ 30000 15000 300
# Medium VAR
python generate_data.py $i $coef_pattern 30 180 ClusterOut/
Rscript run_file_Han_LP.r $i $coef_pattern 30 180 ClusterOut/
python run_file_lasso_enet.py $i $coef_pattern 30 180 ClusterOut/
python run_file_EAS.py $i $coef_pattern 30 180 ClusterOut/ 30000 15000 300
done
done


# Produce the tables found in the simulation section of the paper
# Low dimensional setting table
python out_file_EAS.py random 4 120 100 ClusterOut/
python out_file_oracle.py random 4 120 100 ClusterOut/
for file_name in Han_LP_ lasso_ enet_
do
python out_file_point_est.py random 4 120 100 $file_name ClusterOut/
done
# High dimensional setting tables
for coef_pattern in band cluster hub random scale-free
do
python out_file_EAS.py $coef_pattern 10 20 100 ClusterOut/
python out_file_EAS.py $coef_pattern 30 180 100 ClusterOut/
python out_file_oracle.py $coef_pattern 10 20 100 ClusterOut/
python out_file_oracle.py $coef_pattern 30 180 100 ClusterOut/
for file_name in Han_LP_ lasso_ enet_
do
python out_file_point_est.py $coef_pattern 10 20 100 $file_name ClusterOut/
python out_file_point_est.py $coef_pattern 30 180 100 $file_name ClusterOut/
done
done
mv ClusterOut/results* Output/
cd ..
python out_file.py


# Real data results
cp routine_EAS_VAR1.py Real_data/
cd Real_data/
# Download the real stock data from Yahoo Finance and produce time-seres plots
Rscript get_stock_data.r
# Implement the EAS algorithm on the data
# The 50,000 MCMC steps will run for 3-4 days on these data sets
python run_file_real_data.py 1 50000 15000 50
python run_file_real_data.py 2 50000 15000 50
# Produce the directed graph plots from the EAS algorithm output
python out_file_real_data.py