

#Function to compute initial Beta estimate using OLS, with clustered data.
OLS <- function(nArray,p,Xlist,Ylist) {
	
	m = length(Xlist)
	
	sum1 = 0
	sum2 = 0
	for (s in 1:m) {
		
		X = matrix(unlist(Xlist[s]),nArray[s],p)
		Y_obs = matrix(unlist(Ylist[s]),nArray[s],1)
		sum1 = sum1 + t(X)%*%X
		sum2 = sum2 + t(X)%*%Y_obs
	}
	Beta_hat = ginv(sum1)%*%sum2 
	
	return(Beta_hat)
}


#Function to estimate sigma^2 and D in step 1 of LME iteration.
LME_RE <- function(nArray,Beta_hat,qu,Xlist,Ylist,Zlist) {
	
	m = length(Xlist)
	p = length(Beta_hat)
	
	bMat = matrix(0,qu,m)
	sigmaSQ_hat = 0
	Dsum1 = 0
	Dsum2 = 0
	for (s in 1:m) {
		X = matrix(unlist(Xlist[s]),nArray[s],p)
		Z = matrix(unlist(Zlist[s]),nArray[s],qu)
		Y_obs = matrix(unlist(Ylist[s]),nArray[s],1)

		u = Y_obs - X%*%Beta_hat
		
		b_hat = solve(t(Z)%*%Z)%*%t(Z)%*%u
		bMat[,s] = b_hat
		
		epsilon_hat = u - Z%*%b_hat
		sigmaSQ_hat = sigmaSQ_hat + ( t(epsilon_hat)%*%epsilon_hat / (sum(nArray) - qu*m) )
		
		Dsum1 = Dsum1 + ( b_hat%*%t(b_hat) / m )
		Dsum2 = Dsum2 + ( solve(t(Z)%*%Z) / m )
	}
	D_hat = ( Dsum1 / as.numeric(sigmaSQ_hat) ) - Dsum2
	
	Step1list = list(sigmaSQ_hat=sigmaSQ_hat,D_hat=D_hat,bMat=bMat)	
}


#Function to estimate the weighted LS in step 2 of LME iteration.
LME_FE <- function(nArray,Beta_old,Beta_hat,D_hat,Xlist,Ylist,Zlist) {
	
	m = length(Xlist)
	p = length(Beta_hat)
	qu = length(diag(D_hat))
	
	Wsum1 = 0
	Wsum2 = 0
	for (s in 1:m) {
		X = matrix(unlist(Xlist[s]),nArray[s],p)
		Z = matrix(unlist(Zlist[s]),nArray[s],qu)
		Y_obs = matrix(unlist(Ylist[s]),nArray[s],1)
		
		W = solve(diag(nArray[s]) + Z%*%D_hat%*%t(Z))
		Wsum1 = Wsum1 + t(X)%*%W%*%X
		Wsum2 = Wsum2 + t(X)%*%W%*%Y_obs
	}
	
	Beta_hat = matrix( solve(Wsum1)%*%Wsum2 ,p,1)

	return(Beta_hat)
}


#Function to estimate linear mixed effects.
LME <- function(StoreSimulateLME) {

	nArray = unlist(StoreSimulateLME$nArray)
	m = length(nArray)
	p = as.numeric(unlist(StoreSimulateLME$p))
	qu = as.numeric(unlist(StoreSimulateLME$qu))
	
	Xlist = StoreSimulateLME$Xlist 
	Ylist = StoreSimulateLME$Ylist
	Zlist = StoreSimulateLME$Zlist
	
	#Compute the initial Beta estimate using OLS.	
	Beta_hat = OLS(nArray,p,Xlist,Ylist)
	
	#Begin two stage least squares iteration until convergence.	
	Beta_old = Beta_hat + matrix(1,p,1) 
	D_hat = matrix(0,qu,qu)
	D_old = matrix(1,1,qu)
	count = 0
	while ( ( sqrt( t(Beta_hat - Beta_old)%*%(Beta_hat - Beta_old) ) > 10^(-10) 
			|| sqrt( t(diag(D_hat) - D_old)%*%(diag(D_hat) - D_old) ) > 10^(-10) ) && count < 500 ) {

		Beta_old = Beta_hat
		D_old = diag(D_hat)

		#Step 1. Estimate sigma^2 and D using an initial estimate of Beta
		Step1list = LME_RE(nArray,Beta_hat,qu,Xlist,Ylist,Zlist)
		sigmaSQ_hat = as.numeric(unlist(Step1list$sigmaSQ_hat))
		D_hat = matrix(unlist(Step1list$D_hat),qu,qu)
		bMat = matrix(unlist(Step1list$bMat),qu,m)
		
		#Step 2. Estimate Beta using WLS with the estimates from step 1.
		Beta_hat = LME_FE(nArray,Beta_old,Beta_hat,D_hat,Xlist,Ylist,Zlist)
		
		count = count + 1
	}
	
	StoreLME = list(sigmaSQ_hat=sigmaSQ_hat,Beta_hat=t(Beta_hat),D_hat=D_hat,count=count,bMat=bMat)

	return(StoreLME)
}

library(lme4)
MLE <- function(StoreSimulateLME) {
	
	nArray = unlist(StoreSimulateLME$nArray)
	m = length(nArray)
	p = as.numeric(unlist(StoreSimulateLME$p))
	qu = as.numeric(unlist(StoreSimulateLME$qu))

	Xlist = StoreSimulateLME$Xlist 
	Ylist = StoreSimulateLME$Ylist
	Zlist = StoreSimulateLME$Zlist
	
	bigY = NULL
	bigX = NULL
	bigZ = NULL
	group = NULL
	for (k in 1:m) {

		Y = matrix(unlist(Ylist[k]),nArray[k],1)
		X = matrix(unlist(Xlist[k]),nArray[k],p)
		Z = matrix(unlist(Zlist[k]),nArray[k],qu)
		
		bigY = rbind(bigY,Y)
		bigX = rbind(bigX,X)
		bigZ = rbind(bigZ,Z)	

		NextGroup = rep(k,nArray[k])
		group = c(group,NextGroup)
	}
	
	Y = bigY
	X = as.data.frame(bigX)
	Z = as.data.frame(bigZ)
	
	YXZ = data.frame(Y,X,Z,group)

	ff = "Y ~ -1 + "
	for (k in 1:p) {
		ff = paste(ff, "V", k, "+", sep="")
	}
	ffr = "-1"
	if (qu > p) {
		for (k in 1:p) {
			ffr = paste(ffr,"+","V",k,".1",sep="")
		}
		for (k in (p+1):qu) {
			ffr = paste(ffr,"+","V",k,sep="")
		}
	}
	else {
		for (k in 1:qu) {
			ffr = paste(ffr,"+","V",k,".1",sep="")
		}
	}
	ff.RE = formula(paste(ff, "(",ffr,"|group)", sep=""))

	res = lmer(ff.RE, data=YXZ )
	
	Beta_hat = matrix(fixef(res),p,1)
	
	bMat = as.matrix(ranef(res)$group)

	VarCov = as.data.frame(VarCorr(res))
	D_hat = diag(VarCov$vcov[1:qu],qu)

	DummyMat = diag(qu)*0
	k = qu
	l = qu - 1
	Col = 1
	while (l > 0) {
		
		D_hat[(Col+1):qu,Col] = VarCov$vcov[(k+1):(k+l)]
		DummyMat[(Col+1):qu,Col] = VarCov$vcov[(k+1):(k+l)]
		
		k = k + l
		l = l - 1
		Col = Col + 1
	}
	D_hat = D_hat + t(DummyMat)
	
	sigmaSQ_hat = sigma(res)
	
	MLElist = list(Beta_hat=Beta_hat,D_hat=D_hat,bMat=bMat,sigmaSQ_hat=sigmaSQ_hat)
	
	return(MLElist)
}

