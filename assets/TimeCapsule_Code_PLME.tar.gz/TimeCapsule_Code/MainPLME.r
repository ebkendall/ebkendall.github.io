

BigXYfunc <- function(nArray,Xlist,Ylist,p,qu,m) {
	
	bigY = NULL
	bigX = NULL
	for (k in 1:m) {

		Y = matrix(unlist(Ylist[k]),nArray[k],1)
		X = matrix(unlist(Xlist[k]),nArray[k],p)
				
		bigY = rbind(bigY,Y)
		
		bigX = rbind(bigX,X)
	}
	BigXYlist = list(bigY=bigY,bigX=bigX)
	
	return(BigXYlist)
}


library(Matrix) #To use the function bdiag() for computing block diagonal matrices.
BigWfunc <- function(nArray,Zlist,IndD,D_hat,qu,m) {
	
	D_hat = D_hat[IndD,IndD]
	bigW = 0
	for (k in 1:m) {
		Z = matrix(unlist(Zlist[k]),nArray[k],qu)
		Z = Z[,IndD]
		
		if (sum(IndD)==0) {
			W = ginv( diag(nArray[k]) )
		}
		else {
			W = ginv( diag(nArray[k]) + Z%*%as.matrix(D_hat)%*%t(Z) )
		}

		if (length(bigW) != 1) {
			bigW = as.matrix( bdiag(bigW,W) )		
		}
		else {
			bigW = W
		}
	}

	BigWlist = list(bigW=bigW)
	
	return(BigWlist)
}


Initial <- function(nArray,Xlist,Ylist,Zlist,p,qu,m) {
	
	BigXYlist = BigXYfunc(nArray,Xlist,Ylist,p,qu,m)
	bigX = matrix(unlist(BigXYlist$bigX),sum(nArray),p)
	bigY = matrix(unlist(BigXYlist$bigY),sum(nArray),1)
	
	Beta_LS = ginv( t(bigX)%*%bigX ) %*% t(bigX)%*%bigY
	
	sigmaSQ_hat = 0
	Dsum1 = 0
	Dsum2 = 0
	for (s in 1:m) {
		X = matrix(unlist(Xlist[s]),nArray[s],p)
		Z = matrix(unlist(Zlist[s]),nArray[s],qu)
		Y = matrix(unlist(Ylist[s]),nArray[s],1)

		u = Y - X%*%Beta_LS

		b_hat = ginv( t(Z)%*%Z ) %*% t(Z)%*%u
		
		epsilon_hat = u - Z%*%b_hat

		if (sum(nArray) <= qu*m) {
			sigmaSQ_hat = sigmaSQ_hat + t(epsilon_hat)%*%epsilon_hat  
		}
		else {
			sigmaSQ_hat = sigmaSQ_hat + ( t(epsilon_hat)%*%epsilon_hat / ( sum(nArray) - qu*m ) )
		}
		
		Dsum1 = Dsum1 + ( b_hat%*%t(b_hat) / m )
		Dsum2 = Dsum2 + ( ginv( t(Z)%*%Z ) / m )
	}
	D_hat = ( Dsum1 / as.numeric(sigmaSQ_hat) ) - Dsum2
	
	InitialList = list(Beta_LS=Beta_LS,D_hat=D_hat,sigmaSQ_hat=sigmaSQ_hat)
	
	return(InitialList)
}


#Function to create the diagonal matrix with penalty terms in the PLS estimate of fixed effects.
PenFE <- function(Beta,a,lambda) {

	p = length(Beta)
	Beta = matrix(Beta,p,1)
	PenaltyPrime = rep(0,p)	
	for (k in 1:p) {
		
		if (abs(Beta[k,]) <= lambda) {
			PenaltyPrime[k] = lambda
		}
		else if (lambda < abs(Beta[k,]) && abs(Beta[k,]) <= a*lambda)  {
			PenaltyPrime[k] = (a*lambda - abs(Beta[k,])) / (a - 1)
		}
		else {
			PenaltyPrime[k] = 0
		}
	}
	u1 = c( PenaltyPrime / abs(Beta) )	

	return(diag(u1,p))
}


#Function to create the diagonal matrix with penalty terms in the PLS estimate of random effects.
PenRE <- function(D,a,xi,m,sigmaSQ_hat) {
	
	D = as.matrix(D)
	qu = length(diag(D))
	daigD = matrix(diag(D),qu,1)
	sqrt_daigD = sqrt(abs(daigD))
	PenaltyPrime = rep(0,qu)	
	for (k in 1:qu) {
		
		if (abs(sqrt_daigD[k,]) <= xi) {
			PenaltyPrime[k] = xi
		}
		else if (xi < abs(sqrt_daigD[k,]) && abs(sqrt_daigD[k,]) <= a*xi)  {
			PenaltyPrime[k] = (a*xi - abs(sqrt_daigD[k,])) / (a - 1)
		}
		else {
			PenaltyPrime[k] = 0
		}
	}
	#cat('numerator',PenaltyPrime,'\n')
	#cat('denominator',sqrt_daigD*(m-1)*sigmaSQ_hat,'\n')
	u1 = c( PenaltyPrime / ( sqrt_daigD*(m-1)*sigmaSQ_hat ) )
	#cat('u1',u1,'\n')	
	return(diag(u1,qu))
}	


PenEst <- function(nArray,Xlist,Ylist,Zlist,p,qu,m,Ind,IndD,Beta_old,D_old,a,lambda,xi,sigmaSQ_old) {
	
	#Initial or previous estimate of the fixed effects.
	Beta_new = Beta_old[Ind,]
	bMat = matrix(0,qu,m)
	
	#Penalized estimate of D and sigmaSQ.
	sigmaSQ_hat = 0
	if(sum(IndD)==0) {
		for (s in 1:m) {
			X = matrix(unlist(Xlist[s]),nArray[s],p)
			X = matrix(X[,Ind],nArray[s],sum(Ind))
			Y = matrix(unlist(Ylist[s]),nArray[s],1)
			
			if (sum(Ind)==0) {
				epsilon_hat = Y
			}
			else {
				epsilon_hat = Y - X%*%Beta_new
			}

			if (sum(nArray) <= sum(Ind)) {
				sigmaSQ_hat = sigmaSQ_hat + t(epsilon_hat)%*%epsilon_hat  
			}
			else {
				sigmaSQ_hat = sigmaSQ_hat + ( t(epsilon_hat)%*%epsilon_hat / ( sum(nArray) - sum(Ind) ) )
			}
		}
	}
	else {	
		Dsum1 = 0
		Dsum2 = 0
		for (s in 1:m) {
			X = matrix(unlist(Xlist[s]),nArray[s],p)
			X = matrix(X[,Ind],nArray[s],sum(Ind))
			Z = matrix(unlist(Zlist[s]),nArray[s],qu)		
			Z = matrix(Z[,IndD],nArray[s],sum(IndD))
			Y = matrix(unlist(Ylist[s]),nArray[s],1)

			if (sum(Ind)==0) {
				u = Y
			}
			else {
				u = Y - X%*%Beta_new
			}
			
			RandEffPenalty = PenRE(D_old[IndD,IndD],a,xi,m,sigmaSQ_old)

			b_hat = ginv( t(Z)%*%Z + sum(nArray)*RandEffPenalty ) %*% t(Z)%*%u
			bMat[IndD,s] = b_hat
			
			epsilon_hat = u - Z%*%b_hat
			
			if (sum(nArray) <= sum(IndD)*m) {
				sigmaSQ_hat = sigmaSQ_hat + t(epsilon_hat)%*%epsilon_hat  
			}
			else {
				sigmaSQ_hat = sigmaSQ_hat + ( t(epsilon_hat)%*%epsilon_hat / ( sum(nArray) - sum(IndD)*m ) )
			}
			
			Dsum1 = Dsum1 + ( b_hat%*%t(b_hat) / m )
			Dsum2 = Dsum2 + ( ginv( t(Z)%*%Z ) / m )
		}
		D_old[IndD,IndD] = ( Dsum1 / as.numeric(sigmaSQ_hat) ) - Dsum2
	}
	
	#Penalized estimate of fixed effects.
	D_new = D_old[IndD,IndD]
	if (sum(Ind)!=0) {
		Wsum1 = 0
		Wsum2 = 0
		for (s in 1:m) {
			X = matrix(unlist(Xlist[s]),nArray[s],p)
			X = matrix(X[,Ind],nArray[s],sum(Ind))
			Z = matrix(unlist(Zlist[s]),nArray[s],qu)
			Z = matrix(Z[,IndD],nArray[s],sum(IndD))
			Y = matrix(unlist(Ylist[s]),nArray[s],1)
			
			if (sum(IndD) == 0) {
				W = diag(nArray[s])
			}
			else {
				W = ginv( diag(nArray[s]) + Z%*%D_new%*%t(Z) )
			}
			
			Wsum1 = Wsum1 + t(X)%*%W%*%X
			Wsum2 = Wsum2 + t(X)%*%W%*%Y
		}
		
		FixEffPenalty = PenFE(Beta_new,a,lambda)

		Beta_old[Ind,] = ginv( Wsum1 + sum(nArray)*FixEffPenalty ) %*% Wsum2
	}
	
	PenEstList = list(Beta_old=Beta_old,D_old=D_old,sigmaSQ_hat=sigmaSQ_hat,bMat=bMat)
}


#Function to estimate the SE of LS estimates, ignoring any random effects.
NaiveSE_LS <- function(nArray,m,p,Xlist,sigmaSQ_hat) {
	
	SEsum = 0
	for (k in 1:m) {
		X = matrix(unlist(Xlist[k]),nArray[k],p)
		
		SEsum = SEsum + t(X)%*%X
	}
	SE_LS = sqrt( sigmaSQ_hat*diag(ginv(SEsum)) )
	
	return(SE_LS)
}


BlockDiagZ <- function(Zlist,IndD,nArray,m,qu) {
	for (k in 1:m) {
		Z = matrix(unlist(Zlist[k]),nArray[k],qu)
		Z = Z[,IndD]
		Zlist[[k]] = Z
	}
	bigZ = as.matrix( bdiag(Zlist) )

	return(bigZ)
}


#Function to determine the degrees of freedom.
library(Matrix) #To use the function bdiag() for computing block diagonal matrices.
DegreesOfFreedom <- function(Ind,IndD,bigX,Zlist,D_hat,n,m,qu) {
	
  	bigX = bigX[,Ind]
	D_hat = D_hat[IndD,IndD]
	bigZ = BlockDiagZ(Zlist,IndD,nArray,m,qu)
	qu = sum(IndD)
	p = sum(Ind)
	
	#Compute the square root of D_hat to use in scaling b_i so that cov(Gamma%*%b_i) = cov(epsilon).
	ee = eigen(D_hat,symmetric=TRUE)
	V = ee$vectors
	
	Gamma = V %*% ginv( diag( sqrt(abs(ee$values)), qu) ) %*% ginv(V) # = (D_hat)^(-1/2).
	
	U = matrix(0, n + m*qu, p + m*qu)	
	U[1:n, 1:p] = bigX #Upper left block of U.
	U[1:n, (p+1):(p+qu*m)] = bigZ #Upper right block of U.
	U[(n+1):(n+m*qu), (p+1):(p+qu*m)] = kronecker(diag(m), -Gamma) #Lower right block of U.
	#Lower left block of U are zeros
	
	H1 = U[1:n,] %*% ginv(t(U)%*%U) %*% t(U[1:n,])
	degf = sum(diag(H1))
	
	return(degf)
}


#Calculate the GCV statistic.
GCV <- function(degf,n,Beta_PLS,X,Y_obs,bigW) {
	
	if (length(Beta_PLS)==0) {
		B = Y_obs
	}
	else {
		B = Y_obs - X%*%as.matrix(Beta_PLS)
	}
	
	if (t(B)%*%bigW%*%B < 0) {
		GCV_stat = Inf
		
		return(GCV_stat)
	}
	else{ 		
		GCV_stat = t(B)%*%bigW%*%B / ( n * ( 1 - (degf/n) )^2 )
	
		return(GCV_stat)
	}
}


#Calculate the AIC statistic.
AIC <- function(degf,n,Beta_PLS,X,Y_obs,bigW) {
	
	if (length(Beta_PLS)==0) {
		B = Y_obs
	}
	else {
		B = Y_obs - X%*%as.matrix(Beta_PLS)
	}
	
	if (t(B)%*%bigW%*%B < 0) {
		AIC_stat = Inf
		
		return(AIC_stat)
	}
	else{ 		
		AIC_stat = log( t(B)%*%bigW%*%B / n) + 2*degf/n
	
		return(AIC_stat)
	}
}


#Calculate the BIC statistic.
BIC <- function(degf,n,Beta_PLS,X,Y_obs,bigW) {

	if (length(Beta_PLS)==0) {
		B = Y_obs
	}
	else {
		B = Y_obs - X%*%as.matrix(Beta_PLS)
	}
	
	if (t(B)%*%bigW%*%B < 0) {
		BIC_stat = Inf
		
		return(BIC_stat)
	}
	else{ 		
		BIC_stat = log( t(B)%*%bigW%*%B / n) + degf*log(n)/n
	
		return(BIC_stat)
	}
}

library(glasso)
PLME <- function(StoreSimulateLME,a,lambda,xi,rho,OffDiag) {
	
	nArray = unlist(StoreSimulateLME$nArray)
	m = length(nArray)
	p = as.numeric(unlist(StoreSimulateLME$p))
	qu = as.numeric(unlist(StoreSimulateLME$qu))
	Xlist = StoreSimulateLME$Xlist 
	Ylist = StoreSimulateLME$Ylist
	Zlist = StoreSimulateLME$Zlist
	
	InitialList = Initial(nArray,Xlist,Ylist,Zlist,p,qu,m)
	Beta_hat = matrix(unlist(InitialList$Beta_LS),p,1)
	sigmaSQ_hat = as.numeric(unlist(InitialList$sigmaSQ_hat))
	D_hat = matrix(unlist(InitialList$D_hat),qu,qu)

	StdErrLS_FE = NaiveSE_LS(nArray,m,p,Xlist,sigmaSQ_hat)
	StdErrLS_RE = NaiveSE_LS(nArray,m,qu,Zlist,sigmaSQ_hat)
	
	Ind = rep(TRUE,p)
	IndD = rep(TRUE,qu)
	Beta_old = Beta_hat + matrix(1,p,1) 
	D_old = D_hat + matrix(1,qu,qu)
	count = 0
	MaxCount = 500
	while ( ( sqrt( t(Beta_hat - Beta_old)%*%(Beta_hat - Beta_old) ) > 10^(-10) 
			  || sqrt( t(diag(D_hat) - diag(D_old))%*%(diag(D_hat) - diag(D_old)) ) > 10^(-10) ) 
			  && count < MaxCount ) {
	
		Beta_old = Beta_hat
		D_old = D_hat
		sigmaSQ_old = sigmaSQ_hat

		PenEstList = PenEst(nArray,Xlist,Ylist,Zlist,p,qu,m,Ind,IndD,Beta_old,D_old,a,lambda,xi,sigmaSQ_old)
		Beta_hat = matrix(unlist(PenEstList$Beta_old),p,1)
		D_hat = matrix(unlist(PenEstList$D_old),qu,qu)
		bMat = matrix(unlist(PenEstList$bMat),qu,m)
		sigmaSQ_hat = as.numeric(unlist(PenEstList$sigmaSQ_hat))
		
		#Set "small" fixed effect estimates equal to zero.	
		for(k in 1:p) {
			if ( abs(Beta_hat[k,]) < 10^(-4)*StdErrLS_FE[k] ) {
				Beta_hat[k,] = 0
				Ind[k] = FALSE
			}
		}

		#Set "small" random effect estimates equal to zero.
		for(k in 1:qu) {
			if ( diag(D_hat)[k] < 10^(-4)*StdErrLS_RE[k] ) {
				D_hat[k,] = 0
				D_hat[,k] = 0
				IndD[k] = FALSE
			}
		}
		
		count = count + 1	
	}

	#Implement glasso to penalize the off-diagonal terms of D_hat.
	if (OffDiag==TRUE && sum(IndD)!=0 && rho!=0) {
		OffDiagPenD_hat = glasso(matrix(D_hat[IndD,IndD],sum(IndD),sum(IndD)),maxit=500,rho,penalize.diagonal=FALSE) #Penalize the off-diagonal terms of D_hat.
		D_hat[IndD,IndD] = OffDiagPenD_hat$w
	}

	BigXYlist = BigXYfunc(nArray,Xlist,Ylist,p,qu,m)
	BigWlist = BigWfunc(nArray,Zlist,IndD,D_hat,qu,m)
	bigY = matrix(unlist(BigXYlist$bigY),sum(nArray),1)
	bigX = matrix(unlist(BigXYlist$bigX),sum(nArray),p)
	bigW = matrix(unlist(BigWlist$bigW),sum(nArray),sum(nArray))
	
	#Determine the degrees of freedom in the estimated model.------------------------------------------------------------
	if (sum(IndD)==0 && sum(Ind)==0) {
		degf = 0
	}
	else if (sum(IndD)==0) {
		degf = sum( diag( bigX[,Ind] %*% ginv( t(bigX[,Ind]) %*% bigX[,Ind] ) %*% t(bigX[,Ind]) ) )
	} 
	else if (sum(Ind)==0) {
		bigZ = BlockDiagZ(Zlist,IndD,nArray,m,qu)
		degf = sum( diag( bigZ %*% ginv( t(bigZ) %*% bigZ + 
							kronecker(diag(m), ginv(D_hat[IndD,IndD]) ) ) %*% t(bigZ) ) )
	}
	else {
		degf = DegreesOfFreedom(Ind,IndD,bigX,Zlist,D_hat,sum(nArray),m,qu)
	}
	#---------------------------------------------------------------------------------------------------------------------
	
	GCV_stat = GCV(degf,sum(nArray),Beta_hat[Ind,],bigX[,Ind],bigY,bigW)
	AIC_stat = AIC(degf,sum(nArray),Beta_hat[Ind,],bigX[,Ind],bigY,bigW)
	BIC_stat = BIC(degf,sum(nArray),Beta_hat[Ind,],bigX[,Ind],bigY,bigW)

	StorePLME = list(Beta_hat=Beta_hat,D_hat=D_hat,sigmaSQ_hat=sigmaSQ_hat,count=count,GCV_stat=GCV_stat,
					AIC_stat=AIC_stat,BIC_stat=BIC_stat,bMat=bMat)
	
	return(StorePLME)
}


SearchPLME <- function(StoreSimulateLME,a,LambdaMin,LambdaMax,XiMin,XiMax,RhoMin,RhoMax,increments) {
	
	#Begin searching for the optimal lambda and xi tuning parameters over a two-dimensional grid.
	XiGrid = seq(XiMin,XiMax,by = (XiMax - XiMin) / (increments-1) )
	LambdaGrid = seq(LambdaMin,LambdaMax,by = (LambdaMax - LambdaMin) / (increments-1) )
	
	GCVMat = matrix(Inf,(increments+1),(increments+1))
	AICMat = matrix(Inf,(increments+1),(increments+1))
	BICMat = matrix(Inf,(increments+1),(increments+1))
	SearchCount = 400
	for (k in 1:increments) {
	
		for (s in 1:increments) {
			xi = XiGrid[k]
			lambda = LambdaGrid[s]
			
			StorePLME = PLME(StoreSimulateLME,a,lambda,xi,NULL,OffDiag=FALSE)
			
			GCVMat[k,s] = as.numeric(unlist(StorePLME$GCV_stat))
			AICMat[k,s] = as.numeric(unlist(StorePLME$AIC_stat))
			BICMat[k,s] = as.numeric(unlist(StorePLME$BIC_stat))
			
			if (is.nan(GCVMat[k,s]) || GCVMat[k,s] == -Inf) {
				GCVMat[k,s] = Inf
			}
			if (is.nan(AICMat[k,s]) || AICMat[k,s] == -Inf) {
				AICMat[k,s] = Inf
			}
			if (is.nan(BICMat[k,s]) || BICMat[k,s] == -Inf) {
				BICMat[k,s] = Inf
			}
			SearchCount = SearchCount + 1
			print(SearchCount)
		}
	}
	
	#Find the lambda and xi corresponding to the minimum GCV, AIC, and BIC, respectfully.
	MinGCVMatIndex = which( GCVMat == min(GCVMat) ,arr.ind=TRUE)
	MinGCVMatIndex = MinGCVMatIndex[1,]
	GCVxi = XiGrid[MinGCVMatIndex[1]]
	GCVlambda = LambdaGrid[MinGCVMatIndex[2]]
	
	MinAICMatIndex = which( AICMat == min(AICMat) ,arr.ind=TRUE)
	MinAICMatIndex = MinAICMatIndex[1,]
	AICxi = XiGrid[MinAICMatIndex[1]]
	AIClambda = LambdaGrid[MinAICMatIndex[2]]	
	
	MinBICMatIndex = which( BICMat == min(BICMat) ,arr.ind=TRUE)
	MinBICMatIndex = MinBICMatIndex[1,]
	BICxi = XiGrid[MinBICMatIndex[1]]
	BIClambda = LambdaGrid[MinBICMatIndex[2]]

	#Begin search for the optimal rho over a one-dimensional grid, given the already chosen lambda and xi.
	if (RhoMin==0 && RhoMax==0) {
		RowIncrements = 1
	}
	else {
		RowIncrements = increments
	}
	
	GCVArrayRho = matrix(Inf,2,RowIncrements)
	AICArrayRho = matrix(Inf,2,RowIncrements)
	BICArrayRho = matrix(Inf,2,RowIncrements)
	
	RhoGrid = seq(RhoMin,RhoMax,by = (RhoMax - RhoMin) / (increments-1) )
	
	for (r in 1:RowIncrements) {
		rho = RhoGrid[r]
		
		GCVStorePLME = PLME(StoreSimulateLME,a,GCVlambda,GCVxi,rho,OffDiag=TRUE)
		AICStorePLME = PLME(StoreSimulateLME,a,AIClambda,AICxi,rho,OffDiag=TRUE)
		BICStorePLME = PLME(StoreSimulateLME,a,BIClambda,BICxi,rho,OffDiag=TRUE)
		
		GCVArrayRho[1,r] = as.numeric(unlist(GCVStorePLME$GCV_stat))
		AICArrayRho[1,r] = as.numeric(unlist(AICStorePLME$AIC_stat))
		BICArrayRho[1,r] = as.numeric(unlist(BICStorePLME$BIC_stat))
		
		if (is.nan(GCVArrayRho[1,r]) || GCVArrayRho[1,r] == -Inf) {
			GCVArrayRho[1,r] = Inf
		}
		if (is.nan(AICArrayRho[1,r]) || AICArrayRho[1,r] == -Inf) {
			AICArrayRho[1,r] = Inf
		}
		if (is.nan(BICArrayRho[1,r]) || BICArrayRho[1,r] == -Inf) {
			BICArrayRho[1,r] = Inf
		}
	}

	#Find the rho corresponding to the minimum GCV, AIC, and BIC, respectfully.
	MinGCVArrayRhoIndex = which( GCVArrayRho == min(GCVArrayRho) ,arr.ind=TRUE)
	MinGCVArrayRhoIndex = MinGCVArrayRhoIndex[1,]
	GCVrho = RhoGrid[MinGCVArrayRhoIndex[2]]
	
	MinAICArrayRhoIndex = which( AICArrayRho == min(AICArrayRho) ,arr.ind=TRUE)
	MinAICArrayRhoIndex = MinAICArrayRhoIndex[1,]
	AICrho = RhoGrid[MinAICArrayRhoIndex[2]]	
	
	MinBICArrayRhoIndex = which( BICArrayRho == min(BICArrayRho) ,arr.ind=TRUE)
	MinBICArrayRhoIndex = MinBICArrayRhoIndex[1,]
	BICrho = RhoGrid[MinBICArrayRhoIndex[2]]
	
	#Using the optimal lambda and xi, store the estimation output WITHOUT using glasso.
	GCVlist_NOglasso = PLME(StoreSimulateLME,a,GCVlambda,GCVxi,NULL,OffDiag=FALSE)
	AIClist_NOglasso = PLME(StoreSimulateLME,a,AIClambda,AICxi,NULL,OffDiag=FALSE)
	BIClist_NOglasso = PLME(StoreSimulateLME,a,BIClambda,BICxi,NULL,OffDiag=FALSE)

	#Using the optimal lambda, xi, and rho, store the estimation output WITH using glasso.
	GCVlist_glasso = PLME(StoreSimulateLME,a,GCVlambda,GCVxi,GCVrho,OffDiag=TRUE)
	AIClist_glasso = PLME(StoreSimulateLME,a,AIClambda,AICxi,AICrho,OffDiag=TRUE)
	BIClist_glasso = PLME(StoreSimulateLME,a,BIClambda,BICxi,BICrho,OffDiag=TRUE)
	
	#Create a labelled matrix to show the GCV, AIC, and BIC over the two-dimensional lambda-xi grid.
	GCVMat[(1:increments),(increments+1)] = XiGrid
	GCVMat[(increments+1),(1:increments)] = LambdaGrid
	AICMat[(1:increments),(increments+1)] = XiGrid
	AICMat[(increments+1),(1:increments)] = LambdaGrid
	BICMat[(1:increments),(increments+1)] = XiGrid
	BICMat[(increments+1),(1:increments)] = LambdaGrid
	
	#Create a labelled matrix to show the GCV, AIC, and BIC over the one-dimensional rho grid.
	GCVArrayRho[2,] = RhoGrid
	AICArrayRho[2,] = RhoGrid
	BICArrayRho[2,] = RhoGrid
	
	lambdaChoosen = c(GCVlambda,AIClambda,BIClambda)
	xiChoosen = c(GCVxi,AICxi,BICxi)
	rhoChoosen = c(GCVrho,AICrho,BICrho)
	TunChoiceMat = data.frame(lambdaChoosen,xiChoosen,rhoChoosen,row.names=c("GCV","AIC","BIC"))
	
	SearchPLMElist = list(GCVlist_NOglasso,AIClist_NOglasso,BIClist_NOglasso,GCVlist_glasso,AIClist_glasso,
						  BIClist_glasso,TunChoiceMat=TunChoiceMat,GCVMat=GCVMat,AICMat=AICMat,BICMat=BICMat,
						  GCVArrayRho=GCVArrayRho,AICArrayRho=AICArrayRho,BICArrayRho=BICArrayRho)
	
	return(SearchPLMElist)
}
