

CompileTable1 <- function(qu,Beta,D,BetaMatrix,Dlist,Simulations) {
	
	BetaPropEstZero = colMeans( (BetaMatrix == 0) )

	SumD_hat = rep(0,qu)
	LogicalSumDZero = matrix(0,qu,qu)
	ModelSizeDSum = 0
	for (k in 1:Simulations) {
		
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		SumD_hat = SumD_hat + diag(D_hat)
		LogicalSumDZero = LogicalSumDZero + (D_hat == 0)
		ModelSizeDSum = ModelSizeDSum + sum( (diag(D_hat) != 0) )
	}
	AvgD_hat = SumD_hat / Simulations
	DPropEstZero = diag( LogicalSumDZero / Simulations )
	
	ZeroIndBeta = (Beta == 0)
	FPR_Beta = 1 - mean(BetaPropEstZero[ZeroIndBeta])
	NonZeroIndBeta = (Beta != 0)
	FNR_Beta = mean(BetaPropEstZero[NonZeroIndBeta])
	ModelSize_Beta = mean( rowSums( (BetaMatrix != 0) ) )

	ZeroIndD = (diag(D) == 0)
	FPR_D = 1 - mean(DPropEstZero[ZeroIndD])
	NonZeroIndD = (diag(D) != 0)
	FNR_D = mean(DPropEstZero[NonZeroIndD])
	ModelSize_D = ModelSizeDSum / Simulations

	Table1List = list(FPR_Beta=FPR_Beta,FPR_D=FPR_D,FNR_Beta=FNR_Beta,FNR_D=FNR_D,ModelSize_Beta=ModelSize_Beta,
		   			  ModelSize_D=ModelSize_D)
	
	return(Table1List)
}

GCVtable1 = CompileTable1(qu,Beta,D,GCVBetaMatrix,GCVDlist,Simulations)
AICtable1 = CompileTable1(qu,Beta,D,AICBetaMatrix,AICDlist,Simulations)
BICtable1 = CompileTable1(qu,Beta,D,BICBetaMatrix,BICDlist,Simulations)

FPR = c(NA,GCVtable1$FPR_Beta,AICtable1$FPR_Beta,BICtable1$FPR_Beta,NA,GCVtable1$FPR_D,AICtable1$FPR_D,
		BICtable1$FPR_D)
FNR = c(NA,GCVtable1$FNR_Beta,AICtable1$FNR_Beta,BICtable1$FNR_Beta,NA,GCVtable1$FNR_D,AICtable1$FNR_D,
		BICtable1$FNR_D)
ModelSize = c(NA,GCVtable1$ModelSize_Beta,AICtable1$ModelSize_Beta,BICtable1$ModelSize_Beta,NA,
			  GCVtable1$ModelSize_D,AICtable1$ModelSize_D,BICtable1$ModelSize_D)
Tuning = c("Fixed Effects","GCV","AIC","BIC","Random Effects","GCV","AIC","BIC")
Table1 = data.frame(Tuning,FPR,FNR,ModelSize)




CompileTable2 <- function(qu,Beta,D,BetaMatrix,Dlist,Simulations) {

	IndexBeta = (Beta != 0)
	IndexD = (diag(D) != 0)
	Correct = 0
	CF = 0
	CR = 0
	for (k in 1:Simulations) {
	
		IndexBeta_hat = (BetaMatrix[k,] != 0)
		
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		IndexD_hat = (diag(D_hat) != 0)
		
		if (identical(IndexBeta,IndexBeta_hat) && identical(IndexD,IndexD_hat)) {
			Correct = Correct + 1
		}
		
		if (identical(IndexBeta,IndexBeta_hat)) {
			CF = CF + 1
		}
		
		if (identical(IndexD,IndexD_hat)) {
			CR = CR + 1
		}	
	}
	Correct = round(Correct / Simulations,4)
	CF = round(CF / Simulations,4)
	CR = round(CR /Simulations,4)
	
	Table2List = list(Correct=Correct,CF=CF,CR=CR)
	
	return(Table2List)
}

GCVtable2 = CompileTable2(qu,Beta,D,GCVBetaMatrix,GCVDlist,Simulations)
AICtable2 = CompileTable2(qu,Beta,D,AICBetaMatrix,AICDlist,Simulations)
BICtable2 = CompileTable2(qu,Beta,D,BICBetaMatrix,BICDlist,Simulations)

Correct = c(GCVtable2$Correct,AICtable2$Correct,BICtable2$Correct)
CF = c(GCVtable2$CF,AICtable2$CF,BICtable2$CF)
CR = c(GCVtable2$CR,AICtable2$CR,BICtable2$CR)
Tuning = c("GCV","AIC","BIC")
Table2 = data.frame(Tuning,Correct,CF,CR)



CompileTable3 <- function(p,qu,Beta,D,BetaMatrix,Dlist,Simulations) {
	
	NonZeroIndBeta = (Beta != 0)
	NonZeroIndD = (diag(D) != 0)
	
	BiasBetaMatrix = matrix(0,Simulations,p)
	for (k in 1:Simulations) {
		BiasBetaMatrix[k,][NonZeroIndBeta] = BetaMatrix[k,][NonZeroIndBeta] - Beta[NonZeroIndBeta]
	}
	BiasBeta = colMeans(BiasBetaMatrix[,NonZeroIndBeta])	
	
	
	
	BiasDMatrix = matrix(0,Simulations,qu)
	for (k in 1:Simulations) {
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		BiasDMatrix[k,][NonZeroIndD] = diag(D_hat)[NonZeroIndD] - diag(D)[NonZeroIndD]
	}
	BiasD = colMeans(BiasDMatrix[,NonZeroIndD])
	
	

	MedianBetaMatrix = matrix(0,Simulations,p)
	MedianBeta = rep(0,p)
	MADBetaArray = rep(0,p)
	for (s in 1:p) {
		MedianBeta[s] = median(BetaMatrix[,s])
	}
	for (k in 1:Simulations) {
		MedianBetaMatrix[k,][NonZeroIndBeta] = abs( BetaMatrix[k,][NonZeroIndBeta] - MedianBeta[NonZeroIndBeta] )
	}
	for (r in 1:p) {
		MADBetaArray[r] = median(MedianBetaMatrix[,r])
	}
	MADBetaArray = MADBetaArray[NonZeroIndBeta]
	
	
	
	diagonalDMatrix = matrix(0,Simulations,qu)
	for (k in 1:Simulations) {
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		diagonalDMatrix[k,] = diag(D_hat)
	}
	MedianDMatrix = matrix(0,Simulations,qu)
	MedianD = rep(0,qu)
	MADDArray = rep(0,qu)
	for (s in 1:qu) {
		MedianD[s] = median(diagonalDMatrix[,s])
	}
	for (k in 1:Simulations) {
		MedianDMatrix[k,][NonZeroIndD] = abs( diagonalDMatrix[k,][NonZeroIndD] - MedianD[NonZeroIndD] )
	}
	for (r in 1:qu) {
		MADDArray[r] = median(MedianDMatrix[,r])
	}
	MADDArray = MADDArray[NonZeroIndD]

	Table3List = list(BiasBeta=BiasBeta,BiasD=BiasD,MADBetaArray=MADBetaArray,MADDArray=MADDArray)
	
	return(Table3List)	
}

GCVtable3 = CompileTable3(p,qu,Beta,D,GCVBetaMatrix,GCVDlist,Simulations)
AICtable3 = CompileTable3(p,qu,Beta,D,AICBetaMatrix,AICDlist,Simulations)
BICtable3 = CompileTable3(p,qu,Beta,D,BICBetaMatrix,BICDlist,Simulations)
IterOracle = CompileTable3(p,qu,Beta,D,LMEBetaMatrix,LMEDlist,Simulations)
MLEOracle = CompileTable3(p,qu,Beta,D,MaxLikBetaMatrix,MaxLikDlist,Simulations)
	
Bias_GCV = c("GCV",round(GCVtable3$BiasBeta,2),round(GCVtable3$BiasD,2))
Bias_AIC = c("AIC",round(AICtable3$BiasBeta,2),round(AICtable3$BiasD,2))
Bias_BIC = c("BIC",round(BICtable3$BiasBeta,2),round(BICtable3$BiasD,2))
Bias_IterOracle = c("IterOracle",round(IterOracle$BiasBeta,2),round(IterOracle$BiasD,2))
Bias_MLEOracle = c("MLEOracle",round(MLEOracle$BiasBeta,2),round(MLEOracle$BiasD,2))

Coeff = c(NA,"$beta_1$","$beta_2$","$beta_3$","$beta_4$","$D_11$","$D_22$","$D_33$","$D_44$")
#Coeff = c(NA,"$beta_2$","$beta_3$","$D_11$","$D_22$","$D_33$")

MAD_GCV = c("GCV",round(GCVtable3$MADBetaArray,2),round(GCVtable3$MADDArray,2))
MAD_AIC = c("AIC",round(AICtable3$MADBetaArray,2),round(AICtable3$MADDArray,2))
MAD_BIC = c("BIC",round(BICtable3$MADBetaArray,2),round(BICtable3$MADDArray,2))
MAD_IterOracle = c("IterOracle",round(IterOracle$MADBetaArray,2),round(IterOracle$MADDArray,2))
MAD_MLEOracle = c("MLEOracle",round(MLEOracle$MADBetaArray,2),round(MLEOracle$MADDArray,2))

Table3 = data.frame(Coeff,Bias_GCV,Bias_AIC,Bias_BIC,Bias_IterOracle,Bias_MLEOracle,MAD_GCV,MAD_AIC,MAD_BIC
	                MAD_IterOracle,MAD_MLEOracle)
colnames(Table3) = c(NA,"Bias",NA,NA,NA,NA,"MAD",NA,NA,NA,NA)
	

CompileTable4 <- function(SimulatedDataList,nArray,p,qu,BetaMatrix,blist,Simulations) {

	SSEArray = rep(0,Simulations)
	for(k in 1:Simulations) {	
		
		StoreSimulateLME = SimulatedDataList[[k]]
		Ylist = StoreSimulateLME$Ylist
		Xlist = StoreSimulateLME$Xlist
		Zlist = StoreSimulateLME$Zlist
		
		Beta_hat = matrix(BetaMatrix[k,],p,1)
		bMat = matrix(unlist(blist[k]),qu,m)
		
		m = length(Xlist)
		Y_hat = NULL
		Y = NULL
		for (r in 1:m) {
			
			X = matrix(unlist(Xlist[r]),nArray[r],p)
			Z = matrix(unlist(Zlist[r]),nArray[r],qu)
			b = bMat[,r]
			
			Y_est = X%*%Beta_hat + Z%*%b
			Y_hat = rbind(Y_hat,Y_est)
		
			Y_obs = matrix(unlist(Ylist[r]),nArray[r],1)
			Y = rbind(Y,Y_obs)
		}
		
		Yerror = Y - Y_hat
		
		SSE = t(Yerror)%*%Yerror / sum(nArray)

		SSEArray[k] = SSE
	}
	
	SSE = mean(SSEArray)
	
	return(SSE)
}

GCV_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,GCVBetaMatrix,GCVblist,Simulations)
AIC_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,AICBetaMatrix,AICblist,Simulations)
BIC_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,BICBetaMatrix,BICblist,Simulations)
glassoGCV_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,glassoGCVBetaMatrix,glassoGCVblist,Simulations)
glassoAIC_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,glassoAICBetaMatrix,glassoAICblist,Simulations)
glassoBIC_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,glassoBICBetaMatrix,glassoBICblist,Simulations)
IterOracle_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,LMEBetaMatrix,LMEblist,Simulations)
MLEOracle_SSE = CompileTable4(SimulatedDataList,nArray,p,qu,MaxLikBetaMatrix,MaxLikblist,Simulations)


PredictionError = c(GCV_SSE,AIC_SSE,BIC_SSE)

Table4 = data.frame(GCV_SSE,AIC_SSE,BIC_SSE,glassoGCV_SSE,glassoAIC_SSE,glassoBIC_SSE,IterOracle_SSE,
	                MLEOracle_SSE,row.names=c("Prediction Error"))
colnames(Table4) = c("GCV","AIC","BIC","GCV w/glasso","AIC w/glasso","BIC w/glasso","IterO","MLEO")


CompileTable5 <- function(qu,D,Dlist,Simulations) {
	
	LogicalSumDZero = matrix(0,qu,qu)
	for (k in 1:Simulations) {
		
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		LogicalSumDZero = LogicalSumDZero + (D_hat == 0)
	}
	DPropEstZero = LogicalSumDZero / Simulations 
	
	ZeroIndD = (D == 0) * lower.tri(D,diag=FALSE)
	NonZeroIndD = (D != 0) * lower.tri(D,diag=FALSE)

	FPR_D = round( 1 - ( sum(DPropEstZero*ZeroIndD) / sum(ZeroIndD) ) ,4)

	FNR_D = round( sum(DPropEstZero*NonZeroIndD) / sum(NonZeroIndD) ,4)

	Table5List = list(FPR_D=FPR_D,FNR_D=FNR_D)
	
	return(Table5List)
}

GCVtable5 = CompileTable5(qu,D,GCVDlist,Simulations)
AICtable5 = CompileTable5(qu,D,AICDlist,Simulations)
BICtable5 = CompileTable5(qu,D,BICDlist,Simulations)

glassoGCVtable5 = CompileTable5(qu,D,glassoGCVDlist,Simulations)
glassoAICtable5 = CompileTable5(qu,D,glassoAICDlist,Simulations)
glassoBICtable5 = CompileTable5(qu,D,glassoBICDlist,Simulations)

FPR = c(GCVtable5$FPR_D,AICtable5$FPR_D,BICtable5$FPR_D)
FPRglasso = c(glassoGCVtable5$FPR_D,glassoAICtable5$FPR_D,glassoBICtable5$FPR_D)
FNR = c(GCVtable5$FNR_D,AICtable5$FNR_D,BICtable5$FNR_D)
FNRglasso = c(glassoGCVtable5$FNR_D,glassoAICtable5$FNR_D,glassoBICtable5$FNR_D)

Table5 = data.frame(FPR,FPRglasso,FNR,FNRglasso,row.names=c("GCV","AIC","BIC"))
colnames(Table5) = c("FPR","FPR w/glasso","FNR","FNR w/glasso")


CompileTable6 <- function(qu,D,Dlist,Simulations) {

	NonZeroIndD = (D != 0) * lower.tri(D,diag=FALSE)
	Correct = 0
	for (k in 1:Simulations) {
	
		D_hat = matrix(unlist(Dlist[k]),qu,qu)
		NonZeroIndD_hat = (D_hat != 0) * lower.tri(D,diag=FALSE)
		
		if (identical(NonZeroIndD,NonZeroIndD_hat)) {
			Correct = Correct + 1
		}

	}
	Correct = round(Correct / Simulations,4)
	
	return(Correct)
}

GCVtable6 = CompileTable6(qu,D,GCVDlist,Simulations)
AICtable6 = CompileTable6(qu,D,AICDlist,Simulations)
BICtable6 = CompileTable6(qu,D,BICDlist,Simulations)

glassoGCVtable6 = CompileTable6(qu,D,glassoGCVDlist,Simulations)
glassoAICtable6 = CompileTable6(qu,D,glassoAICDlist,Simulations)
glassoBICtable6 = CompileTable6(qu,D,glassoBICDlist,Simulations)

Correct = c(GCVtable6,AICtable6,BICtable6)
Correctglasso = c(glassoGCVtable6,glassoAICtable6,glassoBICtable6)

Table6 = data.frame(Correct,Correctglasso,row.names=c("GCV","AIC","BIC"))
colnames(Table6) = c("Correct","Correct w/glasso")



