
#Initial Assignments ----------------------------

n = 100 #Number of observations per cluster.

nArray = rep(7,30)

m = length(nArray) #Number of clusters.

sigma = 1

Beta = c(-3.3,1,-7,4.6,0,0,0,0,0,0,0,0)

p = length(Beta)

a = 3.7

D = matrix(c(9,5,   0,   0,0,0,
	         5,7,   0,   0,0,0,
			 0,0,   2,-1.5,0,0,
			 0,0,-1.5,   4,0,0,
			 0,0,   0,   0,0,0,
			 0,0,   0,   0,0,0),6,6)

qu = length(diag(D))

#-----------------------------------------------------------




library(MASS) #This is needed for the function 'mvrnorm().'
#Function to simulate components for a linear mixed effects model.
SimulateLME <- function(nArray,sigma,Beta,D) {
	
	m = length(nArray)
	p = length(Beta) #Number of covariates.
	qu = length(diag(D)) #Number of random effects.
	
	Beta = matrix(Beta,p,1)
	
	#Iterate over each of the m clusters to generate Y_obs.
	Xlist = list(NULL) #Store each cluster of generated X.
	Zlist = list(NULL) #Store each cluster of generated Z.
	Ylist = list(NULL) #Store each cluster of generated Y_obs.
	for (s in 1:m) {
		
		#Randomly generate a design matrix corresponding to fixed effects.
		X = matrix(runif(nArray[s]*(p-1),-2,2),nArray[s],p-1)
		Intercept = matrix(1,nArray[s],1)
		X = cbind(Intercept,X)
		
		#Randomly generate a design matrix corresponding to random effects.
		if (qu <= p) {
			Z = X[,1:qu]
		}
		else {
			Z = X[,1:p]
			AddToZ = matrix(runif( nArray[s]*(qu-p) ,-2,2),nArray[s],(qu-p))
			Z = cbind(Z,AddToZ)
		}
		
		#Randomly generate column of random effects as N(0,(sigma^2)*D)
		b = matrix( mvrnorm(1,rep(0,qu),(sigma^2)*D,empirical=FALSE) ,qu,1)
		
		#Randomly generate a column of errors
		epsilon = matrix(rnorm(nArray[s],0,sigma),nArray[s],1)
		
		#Compute the column of dependent observations.
		Y_obs = X%*%Beta + Z%*%b + epsilon
		
		Xlist[[s]] = X
		Zlist[[s]] = Z
		Ylist[[s]] = Y_obs
	}

	StoreSimulateLME = list(Xlist=Xlist,Ylist=Ylist,Zlist=Zlist,nArray=nArray,p=p,qu=qu)
	
	return(StoreSimulateLME)
}

#Generated Data --------------------------------------------------------------------

StoreSimulateLME = SimulateLME(nArray,sigma,Beta,D) #Randomly generate data for a LME model.

#-----------------------------------------------------------------------------------